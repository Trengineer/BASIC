../GALS/utils/attention_utils.py
